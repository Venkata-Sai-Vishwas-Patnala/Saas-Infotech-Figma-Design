
  # SaaS Dashboard

  This is a code bundle for SaaS Dashboard. The original project is available at https://www.figma.com/design/M7zbhMTr6Ue5vKLN1j22ux/SaaS-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  